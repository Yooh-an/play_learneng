(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-62c5d059.js")
    );
  })().catch(console.error);

})();
