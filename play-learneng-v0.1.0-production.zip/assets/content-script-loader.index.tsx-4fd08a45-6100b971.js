(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-4fd08a45.js")
    );
  })().catch(console.error);

})();
